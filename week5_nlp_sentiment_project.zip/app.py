"""
Week 5 Internship Task — NLP & Sentiment Analysis Dashboard
Amazon Product Reviews — Sentiment Predictor

Run with: streamlit run app.py
"""

import re
import json
import os

import joblib
import pandas as pd
import streamlit as st

# ----------------------------------------------------------------------------
# Page configuration
# ----------------------------------------------------------------------------
st.set_page_config(
    page_title="Sentiment Analysis Dashboard",
    layout="wide",
    initial_sidebar_state="expanded",
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR = os.path.join(BASE_DIR, "assets")
MODELS_DIR = os.path.join(BASE_DIR, "models")
DATA_DIR = os.path.join(BASE_DIR, "data")

# ----------------------------------------------------------------------------
# Theme — deep navy / teal / amber palette, no emoji, professional tone
# ----------------------------------------------------------------------------
PRIMARY = "#2B3A55"
POSITIVE = "#1B998B"
NEGATIVE = "#C1443C"
ACCENT = "#E8A33D"
BG = "#F5F6F8"
CARD_BG = "#FFFFFF"

st.markdown(f"""
<style>
    .stApp {{ background-color: {BG}; }}
    section[data-testid="stSidebar"] {{
        background-color: {PRIMARY};
    }}
    section[data-testid="stSidebar"] * {{
        color: #F2F2F2 !important;
    }}
    div[data-testid="stMetric"] {{
        background-color: {CARD_BG};
        border: 1px solid #E3E3E3;
        border-left: 5px solid {PRIMARY};
        border-radius: 8px;
        padding: 14px 18px 8px 18px;
    }}
    .app-title {{
        font-size: 2.1rem;
        font-weight: 700;
        color: {PRIMARY};
        margin-bottom: 0px;
    }}
    .app-subtitle {{
        font-size: 1.05rem;
        color: #5C6773;
        margin-top: -6px;
    }}
    .section-header {{
        font-size: 1.3rem;
        font-weight: 700;
        color: {PRIMARY};
        border-bottom: 2px solid {ACCENT};
        padding-bottom: 6px;
        margin-top: 18px;
        margin-bottom: 14px;
    }}
    .result-card {{
        border-radius: 10px;
        padding: 22px 26px;
        color: white;
        font-size: 1.15rem;
        font-weight: 600;
    }}
    .info-box {{
        background-color: {CARD_BG};
        border: 1px solid #E3E3E3;
        border-radius: 8px;
        padding: 16px 20px;
    }}
</style>
""", unsafe_allow_html=True)

# ----------------------------------------------------------------------------
# Cached loaders
# ----------------------------------------------------------------------------
@st.cache_resource
def load_model_and_vectorizer():
    model = joblib.load(os.path.join(MODELS_DIR, "best_model.pkl"))
    vectorizer = joblib.load(os.path.join(MODELS_DIR, "vectorizer.pkl"))
    with open(os.path.join(MODELS_DIR, "model_name.txt")) as f:
        model_name = f.read().strip()
    return model, vectorizer, model_name


@st.cache_data
def load_stats():
    with open(os.path.join(MODELS_DIR, "dataset_stats.json")) as f:
        stats = json.load(f)
    comparison = pd.read_csv(os.path.join(MODELS_DIR, "model_comparison.csv"), index_col=0)
    return stats, comparison


STOP_WORDS = None
def get_stopwords():
    global STOP_WORDS
    if STOP_WORDS is None:
        from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
        STOP_WORDS = set(ENGLISH_STOP_WORDS)
    return STOP_WORDS


def normalize(word: str) -> str:
    for suffix in ("ing", "edly", "ed", "es", "s"):
        if word.endswith(suffix) and len(word) - len(suffix) > 2:
            return word[: -len(suffix)]
    return word


def clean_text(text: str) -> str:
    """Identical cleaning pipeline used in the Part 1 notebook."""
    stop_words = get_stopwords()
    text = str(text).lower()
    text = re.sub(r"http\S+|www\.\S+", " ", text)
    text = re.sub(r"<.*?>", " ", text)
    text = re.sub(r"[^a-z\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    tokens = [normalize(w) for w in text.split() if w not in stop_words and len(w) > 2]
    return " ".join(tokens)


# ----------------------------------------------------------------------------
# Sidebar navigation
# ----------------------------------------------------------------------------
st.sidebar.markdown("## Sentiment Analysis")
st.sidebar.caption("Week 5 — NLP Internship Task")
page = st.sidebar.radio(
    "Navigate",
    ["Home", "Data Overview", "Sentiment Predictor"],
    label_visibility="collapsed",
)
st.sidebar.markdown("---")
st.sidebar.caption("Dataset: Amazon customer reviews\nModel: TF-IDF + classical ML classifier")

# ============================================================================
# PAGE 1 — HOME
# ============================================================================
if page == "Home":
    st.markdown('<div class="app-title">Natural Language Processing & Sentiment Analysis</div>', unsafe_allow_html=True)
    st.markdown('<div class="app-subtitle">Understanding customer opinion at scale from raw review text</div>', unsafe_allow_html=True)
    st.write("")

    stats, comparison = load_stats()

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Total Reviews Analyzed", f"{stats['total_reviews']:,}")
    col2.metric("Positive Reviews", f"{stats['positive_reviews']:,}",
                f"{stats['positive_reviews']/stats['total_reviews']*100:.1f}%")
    col3.metric("Negative Reviews", f"{stats['negative_reviews']:,}",
                f"{stats['negative_reviews']/stats['total_reviews']*100:.1f}%", delta_color="inverse")
    col4.metric("Best Model F1-Score", f"{stats['best_f1']*100:.1f}%")

    st.markdown('<div class="section-header">About This Project</div>', unsafe_allow_html=True)
    st.markdown(f"""
    <div class="info-box">
    This dashboard is the Part 2 deliverable of the Week 5 internship task on Natural Language
    Processing. Real Amazon customer reviews were cleaned, vectorized with TF-IDF, and used to
    train and compare multiple text classification models. The best-performing model —
    <b>{stats['best_model']}</b> — was selected using F1-score (rather than raw accuracy, since the
    dataset is imbalanced) and deployed below so any review text can be classified instantly as
    Positive or Negative, along with the model's confidence.
    </div>
    """, unsafe_allow_html=True)

    st.markdown('<div class="section-header">What Is Sentiment Analysis</div>', unsafe_allow_html=True)
    st.markdown("""
    <div class="info-box">
    Sentiment analysis is an NLP technique that automatically determines whether a piece of text
    expresses a positive, negative, or neutral opinion. Text is first cleaned and converted into a
    numerical representation a machine learning model can process, and the model then learns
    patterns in word usage that correlate with each sentiment class. It is widely used to monitor
    product reviews, social media mentions, support tickets, and survey responses at a scale no
    human team could read manually.
    </div>
    """, unsafe_allow_html=True)

    st.markdown('<div class="section-header">How to Use This Dashboard</div>', unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown(f"""<div class="info-box"><b style="color:{PRIMARY}">1. Data Overview</b><br>
        Explore class distribution and word clouds derived from the training data.</div>""", unsafe_allow_html=True)
    with c2:
        st.markdown(f"""<div class="info-box"><b style="color:{PRIMARY}">2. Sentiment Predictor</b><br>
        Type or paste any review text and get an instant sentiment prediction.</div>""", unsafe_allow_html=True)
    with c3:
        st.markdown(f"""<div class="info-box"><b style="color:{PRIMARY}">3. Confidence Score</b><br>
        Every prediction is returned with the model's confidence, not just a label.</div>""", unsafe_allow_html=True)

# ============================================================================
# PAGE 2 — DATA OVERVIEW
# ============================================================================
elif page == "Data Overview":
    st.markdown('<div class="app-title">Data Overview</div>', unsafe_allow_html=True)
    st.markdown('<div class="app-subtitle">Class balance, vocabulary patterns, and model comparison from Part 1</div>', unsafe_allow_html=True)
    st.write("")

    stats, comparison = load_stats()

    st.markdown('<div class="section-header">Class Distribution</div>', unsafe_allow_html=True)
    col1, col2 = st.columns([1, 1.3])
    with col1:
        dist_df = pd.DataFrame({
            "Sentiment": ["Positive", "Negative"],
            "Count": [stats["positive_reviews"], stats["negative_reviews"]],
        })
        st.dataframe(dist_df, hide_index=True, width="stretch")
        st.markdown(f"""
        <div class="info-box">
        The dataset is imbalanced — roughly
        <b>{stats['positive_reviews']/stats['negative_reviews']:.1f} : 1</b> positive-to-negative
        ratio. This was handled during training with stratified splitting and class-weighted
        models so the classifier does not simply default to predicting "Positive".
        </div>
        """, unsafe_allow_html=True)
    with col2:
        st.image(os.path.join(ASSETS_DIR, "outputs_class_distribution.png"), width="stretch")

    st.markdown('<div class="section-header">Word Clouds — Positive vs Negative Reviews</div>', unsafe_allow_html=True)
    st.image(os.path.join(ASSETS_DIR, "outputs_wordclouds.png"), width="stretch")
    st.caption("Positive reviews are dominated by usability and satisfaction terms; negative "
               "reviews surface connectivity and reliability complaints.")

    st.markdown('<div class="section-header">Model Comparison</div>', unsafe_allow_html=True)
    col1, col2 = st.columns([1.3, 1])
    with col1:
        st.image(os.path.join(ASSETS_DIR, "outputs_model_comparison.png"), width="stretch")
    with col2:
        st.dataframe(comparison.style.highlight_max(axis=0, color=f"{POSITIVE}33"), width="stretch")
        st.markdown(f"""
        <div class="info-box">
        <b>{stats['best_model']}</b> was selected as the production model, deployed on the
        Sentiment Predictor page, with an F1-score of <b>{stats['best_f1']*100:.1f}%</b> and
        accuracy of <b>{stats['best_accuracy']*100:.1f}%</b>.
        </div>
        """, unsafe_allow_html=True)

    st.markdown('<div class="section-header">Confusion Matrices</div>', unsafe_allow_html=True)
    st.image(os.path.join(ASSETS_DIR, "outputs_confusion_matrices.png"), width="stretch")

# ============================================================================
# PAGE 3 — SENTIMENT PREDICTOR
# ============================================================================
elif page == "Sentiment Predictor":
    st.markdown('<div class="app-title">Sentiment Predictor</div>', unsafe_allow_html=True)
    st.markdown('<div class="app-subtitle">Type or paste any product review to classify its sentiment</div>', unsafe_allow_html=True)
    st.write("")

    model, vectorizer, model_name = load_model_and_vectorizer()
    st.caption(f"Serving model: {model_name}")

    review_text = st.text_area(
        "Review text",
        height=140,
        placeholder="e.g. The sound quality is amazing and it connects instantly every time...",
        label_visibility="collapsed",
    )

    predict_clicked = st.button("Predict Sentiment", type="primary", use_container_width=False)

    if predict_clicked:
        if not review_text.strip():
            st.warning("Please enter some review text before predicting.")
        else:
            cleaned = clean_text(review_text)
            if not cleaned:
                st.warning("The text contained no usable words after cleaning. Try a more descriptive review.")
            else:
                vec = vectorizer.transform([cleaned])
                pred = model.predict(vec)[0]
                proba = model.predict_proba(vec)[0]
                classes = list(model.classes_)
                pos_idx = classes.index(1)
                neg_idx = classes.index(0)
                pos_conf = proba[pos_idx]
                neg_conf = proba[neg_idx]
                confidence = pos_conf if pred == 1 else neg_conf

                label = "Positive" if pred == 1 else "Negative"
                color = POSITIVE if pred == 1 else NEGATIVE

                st.markdown(f"""
                <div class="result-card" style="background-color:{color};">
                    Predicted Sentiment: {label} &nbsp;&nbsp;|&nbsp;&nbsp; Confidence: {confidence*100:.1f}%
                </div>
                """, unsafe_allow_html=True)

                st.write("")
                st.markdown('<div class="section-header">Prediction Breakdown</div>', unsafe_allow_html=True)
                breakdown = pd.DataFrame({
                    "Sentiment": ["Positive", "Negative"],
                    "Probability": [pos_conf, neg_conf],
                })
                st.bar_chart(breakdown.set_index("Sentiment"), color=[POSITIVE], width="stretch")

                with st.expander("View cleaned text used by the model"):
                    st.code(cleaned, language=None)

    st.markdown('<div class="section-header">About the Model</div>', unsafe_allow_html=True)
    st.markdown(f"""
    <div class="info-box">
    Input text is cleaned using the exact same pipeline as Part 1 of the notebook — lowercasing,
    URL/HTML/punctuation removal, stopword removal, and suffix normalization — before being
    converted into TF-IDF features and passed to the trained <b>{model_name}</b> classifier.
    This ensures the prediction here is consistent with the evaluation reported on the
    Data Overview page.
    </div>
    """, unsafe_allow_html=True)
